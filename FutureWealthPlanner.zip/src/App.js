import React, { useState } from "react";
import InvestmentPlanner from "./pages/InvestmentPlanner";

function App() {
  return (
    <div>
      <h1>Future Wealth Planner</h1>
      <InvestmentPlanner />
    </div>
  );
}

export default App;
