import React, { useState } from "react";

function InvestmentPlanner() {
  const [investment, setInvestment] = useState(10000);
  const [goal, setGoal] = useState("Buy a Car");

  return (
    <div>
      <h2>Investment Planner</h2>
      <label>Investment Amount:</label>
      <input type="number" value={investment} onChange={(e) => setInvestment(e.target.value)} />
      <label>Goal:</label>
      <input type="text" value={goal} onChange={(e) => setGoal(e.target.value)} />
    </div>
  );
}

export default InvestmentPlanner;
